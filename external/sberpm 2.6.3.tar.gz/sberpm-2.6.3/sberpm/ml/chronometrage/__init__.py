from ._chronometrage import Chronometrage

__all__ = ['Chronometrage']

