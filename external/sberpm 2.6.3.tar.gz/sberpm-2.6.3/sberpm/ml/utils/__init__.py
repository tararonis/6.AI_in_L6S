from sberpm.ml.utils._perm_importance import PermutationImportance

__all__ = ["PermutationImportance"]
